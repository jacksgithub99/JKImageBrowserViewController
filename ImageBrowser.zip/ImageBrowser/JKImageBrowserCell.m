//
//  Created by Jack/Zark on 2019/5/16.
//  Copyright © Jack/Zark All rights reserved.
//


#import "JKImageBrowserCell.h"
#import "JKTools.h"
#import "UIImageView+webcache.h"

@interface JKImageBrowserCellZoomView ()<UIScrollViewDelegate> {
    UIImageView *_imageView;
    
    CGSize _screenSize;
    CGFloat _screenWdith;
    CGFloat _screenHeight;
}
@end

@implementation JKImageBrowserCellZoomView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor blackColor];
        
        _screenSize = [UIScreen mainScreen].bounds.size;
        _screenWdith = _screenSize.width;
        _screenHeight = _screenSize.height;
        
        self.delegate = self;
        
        self.minimumZoomScale = 1;
        self.maximumZoomScale = 3;
        
        _imageView = [[UIImageView alloc] init];
        _imageView.userInteractionEnabled = YES;
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        _imageView.clipsToBounds = YES;
        [self addSubview:_imageView];
    }
    return self;
}

- (void)setSourceImageModel:(JKImagePickerModel *)sourceImageModel {
    _sourceImageModel = sourceImageModel;
    UIImage *image = sourceImageModel.image;
    NSString *urlStr = [sourceImageModel getImageUrlSmallImageFirst:NO];
    NSURL *url = nil;
    if (urlStr) {
        url = [NSURL URLWithString:[JKTools encodeUrlStringWith:urlStr]];
    }
    if (image) {
        _imageView.image = image;
        CGRect imageFrame = [self frameFromImage:image];
        [self resetContentWith:imageFrame];
        _imageView.frame = imageFrame;
        [self updateImageFrameInWindow];
    }else if (url) {
        __weak typeof(self) weakSelf = self;
        [_imageView sd_setImageWithURL:url completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            UIImage *loadImage = image;
            if (loadImage) {
                CGRect imageFrame = [strongSelf frameFromImage:loadImage];
                [strongSelf resetContentWith:imageFrame];
                strongSelf->_imageView.frame = imageFrame;
                [strongSelf updateImageFrameInWindow];
            }
        }];
    }else {
        _imageView.image = nil;//placeHolder
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *touch = touches.allObjects.firstObject;
    if (!touch) {
        return;
    }
    if (touch.tapCount == 1) {
        [self performSelector:@selector(sigle_tap) withObject:nil afterDelay:0.2];
    }else if (touch.tapCount == 2) {
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
        CGPoint tapPoint = [touch locationInView:_imageView];
        [self double_tap:tapPoint];
    }
}

- (void)sigle_tap {
    if (_dismiss_callback) {
        _dismiss_callback();
    }
}

- (void)double_tap: (CGPoint)tapPoint {
    if (self.zoomScale > self.minimumZoomScale) {
        //恢复原始大小
        [self setZoomScale:self.minimumZoomScale animated:YES];
    }else {
        //放大到最大
        CGFloat widthofZoomOutAreaofImage = _imageView.bounds.size.width/self.maximumZoomScale;
        CGFloat heightofZoomOutAreaofImage = _imageView.bounds.size.height/self.maximumZoomScale;
        CGFloat xofZoomOutAreaofImage = tapPoint.x - widthofZoomOutAreaofImage/2.0;
        CGFloat yofZoomOutAreaofImage = tapPoint.y - heightofZoomOutAreaofImage/2.0;
        CGRect zoomOutAreaofImage = CGRectMake(xofZoomOutAreaofImage, yofZoomOutAreaofImage, widthofZoomOutAreaofImage, heightofZoomOutAreaofImage);
        [self zoomToRect:zoomOutAreaofImage animated:YES];
    }
}

- (CGRect)frameFromImage: (UIImage *)image {
    CGFloat zoomViewWidth = self.bounds.size.width;
    CGFloat zoomViewHeight = self.bounds.size.height;
    
    CGSize imageSize = image.size;
    
    CGFloat aspectRatio = imageSize.width/imageSize.height;
    CGFloat width = 0;
    CGFloat height = 0;
    if (aspectRatio > zoomViewWidth/zoomViewHeight) {
        width = zoomViewWidth;
        height = width/aspectRatio;
    }else {
        height = zoomViewHeight;
        width = height*aspectRatio;
    }
    
    CGFloat fx = (zoomViewWidth - width)/2;
    CGFloat fy = (zoomViewHeight - height)/2;
    
    return CGRectMake(fx, fy, width, height);
}

- (CGRect)currentImageFrameInWindow {
    CGRect frame = _imageView.frame;
    CGRect frameInWindow = [self convertRect:frame toView:[UIApplication sharedApplication].keyWindow];
    return frameInWindow;
}

- (void)resetContentWith: (CGRect)imageViewFrame {
    self.contentSize = imageViewFrame.size;
    self.contentOffset = CGPointZero;
}

- (void)updateImageFrameInWindow {
    if (self.currentImageFrameCallback_ZoomView) {
        self.currentImageFrameCallback_ZoomView([self currentImageFrameInWindow]);
    }
}

#pragma mark - UIScrollViewDelegate

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    return _imageView;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    CGRect frame = _imageView.frame;
    frame.origin = CGPointZero;
    if (frame.size.width < _screenWdith) {
        frame.origin.x = (_screenWdith - frame.size.width)/2;
    }
    if (frame.size.height < _screenHeight) {
        frame.origin.y = (_screenHeight - frame.size.height)/2;
    }
    _imageView.frame = frame;
}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(CGFloat)scale {
    [scrollView setZoomScale:scale animated:NO];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //保证zoom或者scroll之后，都能更新到最新的值！，如果值不是最新的，（dismiss动画）会发生跳动！
        [self updateImageFrameInWindow];
    });
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //滚动之后，在window中的坐标发生了变化！
    [self updateImageFrameInWindow];
}

@end

@interface JKImageBrowserCell () {
    JKImageBrowserCellZoomView *_zoomScroll;
    
    CGSize _screenSize;
    CGFloat _screenWdith;
    CGFloat _screenHeight;
}

@end

@implementation JKImageBrowserCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _screenSize = [UIScreen mainScreen].bounds.size;
        _screenWdith = _screenSize.width;
        _screenHeight = _screenSize.height;
        
        __weak typeof(self) weakSelf = self;
        _zoomScroll = [[JKImageBrowserCellZoomView alloc] initWithFrame:CGRectMake(0, 0, _screenWdith, _screenHeight)];
        _zoomScroll.dismiss_callback = ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (strongSelf.dismiss_callback) {
                strongSelf.dismiss_callback();
            }
        };
        _zoomScroll.currentImageFrameCallback_ZoomView = ^(CGRect currentFrame) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (strongSelf.currentImageFrameCallback_Cell) {
                strongSelf.currentImageFrameCallback_Cell(currentFrame);
            }
        };
        [self addSubview:_zoomScroll];
    }
    return self;
}

- (void)firstSetImageFrameToAnimator {
    if (self.currentImageFrameCallback_Cell) {
        self.currentImageFrameCallback_Cell(_zoomScroll.currentImageFrameInWindow);
    }
}

- (void)updateImageFrameInWindow {
    [_zoomScroll updateImageFrameInWindow];
}

- (void)setSourceImageModel:(JKImagePickerModel *)sourceImageModel {
    _sourceImageModel = sourceImageModel;
    _zoomScroll.sourceImageModel = sourceImageModel;
}


@end
