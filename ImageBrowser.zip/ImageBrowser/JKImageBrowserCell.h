//
//  Created by Jack/Zark on 2019/5/16.
//  Copyright © Jack/Zark All rights reserved.
//


#import <UIKit/UIKit.h>
#import "JKImagePickerModel.h"

NS_ASSUME_NONNULL_BEGIN

const static CGFloat JKImageBrowserImageSpacing = 50;

//JKImageBrowserCellZoomView作为JKImageBrowserCell的subView/myContentView
//因为UIScrollView自带有缩放相关的手势、功能，所以用UIScrollView作为单个图片的容器，方便实现缩放操作。
@interface JKImageBrowserCellZoomView : UIScrollView

@property (nonatomic, strong) JKImagePickerModel *sourceImageModel;

@property (nonatomic, copy)  void (^dismiss_callback)(void);

@property (nonatomic, copy)  void (^currentImageFrameCallback_ZoomView)(CGRect);

- (CGRect)currentImageFrameInWindow;

- (void)updateImageFrameInWindow;

@end

//使用JKImageBrowserCellZoomView作为self的subview/myContentView
@interface JKImageBrowserCell : UICollectionViewCell

@property (nonatomic, strong) JKImagePickerModel *sourceImageModel;

@property (nonatomic, copy)  void (^dismiss_callback)(void);

@property (nonatomic, copy)  void (^currentImageFrameCallback_Cell)(CGRect);

- (void)updateImageFrameInWindow;

- (void)firstSetImageFrameToAnimator;

@end

NS_ASSUME_NONNULL_END
