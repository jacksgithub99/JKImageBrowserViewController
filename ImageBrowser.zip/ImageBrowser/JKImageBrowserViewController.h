//
//  Created by Jack/Zark on 2019/5/16.
//  Copyright © Jack/Zark All rights reserved.
//


#import <UIKit/UIKit.h>
#import "JKImagePickerModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface JKImageBrowserViewController : UIViewController

@property (nonatomic, strong) NSMutableArray *sourceImageArray;

@end

NS_ASSUME_NONNULL_END
