//
//  Created by Jack/Zark on 2019/5/16.
//  Copyright © Jack/Zark All rights reserved.
//


#import "JKImageBrowserAnimator.h"
#import "JKTools.h"
#import "UIImageView+webcache.h"

const static CGFloat JKImageBrowserImageMaskGrayValue = 0/255.0;
@interface JKImageBrowserPresentAnimator() {

}

@end

@implementation JKImageBrowserPresentAnimator

#pragma mark - UIViewControllerAnimatedTransitioning
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.25;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    UIView *toView = [transitionContext viewForKey:UITransitionContextToViewKey];   //将要展示的controller.view；即JKImageBrowserViewController.view
    if (!toView) {
        return;
    }
    JKImageBrowserTransitionParameter *parameter = self.transitionParameter;
    if (!parameter) {
        return;
    }
    id delegate = parameter.delegate;
    if (!delegate) {
        return;
    }
    toView.hidden = YES;
    [transitionContext.containerView addSubview:toView];
    //黑色背景
    UIView *bgView = [[UIView alloc] initWithFrame:transitionContext.containerView.bounds];
    bgView.backgroundColor = [UIColor blackColor];
    bgView.alpha = 0;
    [transitionContext.containerView addSubview:bgView];
    
    CGRect originFrame = [delegate getOriginImageFrameAt:parameter.imageIndex];
    //遮挡原始图片，直到动画结束
    UIView *whiteMask = [[UIView alloc] initWithFrame:originFrame];
    whiteMask.backgroundColor = [UIColor colorWithRed:JKImageBrowserImageMaskGrayValue green:JKImageBrowserImageMaskGrayValue blue:JKImageBrowserImageMaskGrayValue alpha:1];
    [transitionContext.containerView addSubview:whiteMask];
    
    UIImageView *transitionImageView = [[UIImageView alloc] initWithFrame:originFrame];
    UIImage *image = parameter.sourceImageModel.image;
    NSString *imageUrl = [parameter.sourceImageModel getImageUrlSmallImageFirst:NO];
    if (image) {
        transitionImageView.image = image;
    }else if (imageUrl) {
        NSURL *url = [NSURL URLWithString:[JKTools encodeUrlStringWith:imageUrl]];
        if (url) {
            [transitionImageView sd_setImageWithURL:url];
        }
    }
    [transitionContext.containerView addSubview:transitionImageView];
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        bgView.alpha = 1;
        transitionImageView.frame = [delegate getFinalImageFrameAt:parameter.imageIndex];
    } completion:^(BOOL finished) {
        toView.hidden = NO;
        [whiteMask removeFromSuperview];
        [bgView removeFromSuperview];
        [transitionImageView removeFromSuperview];
        
        [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
    }];
}

@end

#pragma mark - JKImageBrowserDismissAnimator

@interface JKImageBrowserDismissAnimator () {
    
}

@end

@implementation JKImageBrowserDismissAnimator

- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.7;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    UIView *toView = [transitionContext viewForKey:UITransitionContextToViewKey];   //UINavigationController->UILayoutContainerView;Don't hide me!!!
    if (!toView) {
        return;
    }
    JKImageBrowserTransitionParameter *parameter = self.transitionParameter;
    if (!parameter) {
        return;
    }
    id delegate = parameter.delegate;
    if (!delegate) {
        return;
    }

    [transitionContext.containerView addSubview:toView];
    //黑色背景
    UIView *bgView = [[UIView alloc] initWithFrame:transitionContext.containerView.bounds];
    bgView.backgroundColor = [UIColor blackColor];
    bgView.alpha = 0;
    [transitionContext.containerView addSubview:bgView];
    
    CGRect originFrame = [delegate getOriginImageFrameAt:parameter.imageIndex];
    //遮挡原始图片，直到动画结束
    UIView *whiteMask = [[UIView alloc] initWithFrame:originFrame];
    whiteMask.backgroundColor = [UIColor colorWithRed:JKImageBrowserImageMaskGrayValue green:JKImageBrowserImageMaskGrayValue blue:JKImageBrowserImageMaskGrayValue alpha:1];
    [transitionContext.containerView addSubview:whiteMask];
    
    CGRect tranFrame = [transitionContext.containerView convertRect:self.currentImageFrameInWindow fromCoordinateSpace:[UIApplication sharedApplication].keyWindow];
    tranFrame.origin.y = tranFrame.origin.y;
    
    UIImageView *transitionImageView = [[UIImageView alloc] initWithFrame:tranFrame];
    
    UIImage *image = parameter.sourceImageModel.image;
    NSString *imageUrl = [parameter.sourceImageModel getImageUrlSmallImageFirst:NO];
    if (image) {
        transitionImageView.image = image;
    }else if (imageUrl) {
        NSURL *url = [NSURL URLWithString:[JKTools encodeUrlStringWith:imageUrl]];
        if (url) {
            [transitionImageView sd_setImageWithURL:url];
        }
    }
    [transitionContext.containerView addSubview:transitionImageView];
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        transitionImageView.frame = originFrame;
        bgView.alpha = 0;
    } completion:^(BOOL finished) {
        [bgView removeFromSuperview];
        [whiteMask removeFromSuperview];
        [transitionImageView removeFromSuperview];
        
       [transitionContext completeTransition: ![transitionContext transitionWasCancelled]];
    }];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _currentImageFrameInWindow = CGRectZero;
    }
    return self;
}

@end
