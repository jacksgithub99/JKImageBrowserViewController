//
//  Created by Jack/Zark on 2019/5/16.
//  Copyright © Jack/Zark All rights reserved.
//


#import <Foundation/Foundation.h>
#import "JKImageBrowserTransitionParameter.h"

//动画过渡

NS_ASSUME_NONNULL_BEGIN

@interface JKImageBrowserPresentAnimator : NSObject<UIViewControllerAnimatedTransitioning>

@property (nonatomic, strong) JKImageBrowserTransitionParameter *transitionParameter;

@end

@interface JKImageBrowserDismissAnimator : NSObject<UIViewControllerAnimatedTransitioning>

@property (nonatomic, strong) JKImageBrowserTransitionParameter *transitionParameter;

@property (nonatomic, assign) CGRect currentImageFrameInWindow;

@end

NS_ASSUME_NONNULL_END
