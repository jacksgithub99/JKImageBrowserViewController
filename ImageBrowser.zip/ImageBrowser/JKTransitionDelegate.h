//
//  Created by Jack/Zark on 2019/5/16.
//  Copyright © Jack/Zark All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JKImageBrowserAnimator.h"
#import "JKImageBrowserTransitionParameter.h"

NS_ASSUME_NONNULL_BEGIN

@interface JKTransitionDelegate : NSObject<UIViewControllerTransitioningDelegate>

@property (nonatomic, strong) JKImageBrowserPresentAnimator *transitionAnimatorPresent;
@property (nonatomic, strong) JKImageBrowserDismissAnimator *transitionAnimatorDismiss;

@property (nonatomic, strong) JKImageBrowserTransitionParameter *transitionParameter;

@property (nonatomic, assign) CGRect currentImageFrame;

@end

NS_ASSUME_NONNULL_END
