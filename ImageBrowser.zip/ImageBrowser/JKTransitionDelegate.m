//
//  Created by Jack/Zark on 2019/5/16.
//  Copyright © Jack/Zark All rights reserved.
//


#import "JKTransitionDelegate.h"
#import "JKImageBrowserAnimator.h"

@interface JKTransitionDelegate ()



@end

@implementation JKTransitionDelegate

- (instancetype)init
{
    self = [super init];
    if (self) {
        _transitionAnimatorPresent = [[JKImageBrowserPresentAnimator alloc] init];
        _transitionAnimatorDismiss = [[JKImageBrowserDismissAnimator alloc] init];
        
        _currentImageFrame = CGRectZero;
    }
    return self;
}

- (void)setCurrentImageFrame:(CGRect)currentImageFrame {
    _currentImageFrame = currentImageFrame;
    _transitionAnimatorDismiss.currentImageFrameInWindow = currentImageFrame;
}

- (void)setTransitionParameter:(JKImageBrowserTransitionParameter *)transitionParameter {
    _transitionParameter = transitionParameter;
    _transitionAnimatorPresent.transitionParameter = transitionParameter;
    _transitionAnimatorDismiss.transitionParameter = transitionParameter;
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    return _transitionAnimatorPresent;
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return _transitionAnimatorDismiss;
}

- (id<UIViewControllerInteractiveTransitioning>)interactionControllerForPresentation:(id<UIViewControllerAnimatedTransitioning>)animator {
    return nil;
}

- (id<UIViewControllerInteractiveTransitioning>)interactionControllerForDismissal:(id<UIViewControllerAnimatedTransitioning>)animator {
    return nil;
}

@end
