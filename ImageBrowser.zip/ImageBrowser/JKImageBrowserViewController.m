//
//  Created by Jack/Zark on 2019/5/16.
//  Copyright © Jack/Zark All rights reserved.
//


#import "JKImageBrowserViewController.h"
#import "JKImageBrowserCell.h"
#import "JKTransitionDelegate.h"

@interface JKImageBrowserViewController ()<UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSString *_cellID;
}

@end

@implementation JKImageBrowserViewController

- (BOOL)prefersStatusBarHidden {
    return YES; //隐藏状态栏
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupUI];
    [self initData];
}

- (void)setupUI {
    self.automaticallyAdjustsScrollViewInsets = NO;
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumLineSpacing = 0;
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    layout.sectionInset = UIEdgeInsetsZero;
    layout.minimumInteritemSpacing = 0;
    
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    CGFloat screenWidth = screenSize.width;
    CGFloat screenHeight = screenSize.height;
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, screenWidth + JKImageBrowserImageSpacing, screenHeight) collectionViewLayout:layout];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    _collectionView.pagingEnabled = YES;
    _collectionView.showsHorizontalScrollIndicator = NO;
    _collectionView.backgroundView = nil;
    _collectionView.backgroundColor = [UIColor blackColor];
    _cellID = @"JKImageBrowserCellID";
    [_collectionView registerClass:[JKImageBrowserCell class] forCellWithReuseIdentifier:_cellID];
    [self.view addSubview:_collectionView];
    
    JKTransitionDelegate *transition = self.transitioningDelegate;
    JKImageBrowserTransitionParameter *transitionParameter = transition.transitionAnimatorPresent.transitionParameter;
    if (transition && [transition isKindOfClass:[JKTransitionDelegate class]] && transitionParameter) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:transitionParameter.imageIndex inSection:0];
        [_collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];
    }
}

- (void)initData {
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    JKTransitionDelegate *transition = self.transitioningDelegate;
    JKImageBrowserTransitionParameter *transitionParameter = transition.transitionAnimatorPresent.transitionParameter;
    if (transition && [transition isKindOfClass:[JKTransitionDelegate class]] && transitionParameter) {
        [self setTransitionParameterForItemAt:transitionParameter.imageIndex];
    }
}

- (void)setTransitionParameterForItemAt: (NSInteger)index {
    JKTransitionDelegate *transition = self.transitioningDelegate;
    if (transition && [transition isKindOfClass:[JKTransitionDelegate class]]) {
        JKImageBrowserTransitionParameter *transitionParameter = transition.transitionAnimatorDismiss.transitionParameter;
        transitionParameter.imageIndex = index;
        if (index >= 0 && index < _sourceImageArray.count) {
            transition.transitionAnimatorDismiss.transitionParameter.sourceImageModel = _sourceImageArray[index];
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:index inSection:0];
            UICollectionViewCell *cell = [_collectionView cellForItemAtIndexPath:indexPath];
            if (cell && [cell isKindOfClass:[JKImageBrowserCell class]]) {
                [((JKImageBrowserCell *)cell) updateImageFrameInWindow];
            }
        }
    }
    
}
#pragma mark - UICollectionViewDelegateFlowLayout
#pragma mark - UICollectionViewDataSource, UICollectionViewDelegate

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    NSLog(@"count--------------%zd", _sourceImageArray.count);
    return _sourceImageArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    JKImageBrowserCell *cell = (JKImageBrowserCell *)[collectionView dequeueReusableCellWithReuseIdentifier:_cellID forIndexPath:indexPath];
    cell.sourceImageModel = _sourceImageArray[indexPath.item];
    cell.dismiss_callback = ^{
        NSLog(@"self dismissViewControllerAnimated");
        [self dismissViewControllerAnimated:YES completion:nil];
    };
    cell.currentImageFrameCallback_Cell = ^(CGRect frame) {
        JKTransitionDelegate *transition = self.transitioningDelegate;
        if (transition && [transition isKindOfClass:[JKTransitionDelegate class]]) {
            transition.transitionAnimatorDismiss.currentImageFrameInWindow = frame;
        }
    };
    [cell firstSetImageFrameToAnimator];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    CGFloat screenWidth = screenSize.width;
    CGFloat screenHeight = screenSize.height;
    return CGSizeMake(screenWidth + JKImageBrowserImageSpacing, screenHeight);
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    CGFloat offset = scrollView.contentOffset.x;
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    CGFloat screenWidth = screenSize.width;
    NSInteger cellIndex = (NSInteger)(offset/(screenWidth + JKImageBrowserImageSpacing));
    [self setTransitionParameterForItemAt:cellIndex];
}

@end
